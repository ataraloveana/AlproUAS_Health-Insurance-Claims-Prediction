# No Questions Asked Form & Magic Focus

A Pen created on CodePen.io. Original URL: [https://codepen.io/mican/pen/dRWxZe](https://codepen.io/mican/pen/dRWxZe).

Recreation of No Questions Asked form

http://www.noquestionsasked.nyc/challengers/new

plus MAGIC FOCUS

Haml & Sass & CoffeeScript