# glowy hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/inescodes/pen/PoxMyvX](https://codepen.io/inescodes/pen/PoxMyvX).

Inspired by the hover effects in Linear's features page